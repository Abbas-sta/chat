import bcrypt from "bcryptjs";
import User from "../models/model.users.js";
import generateTokenAndSetCookie from "../utils/generateToken.js";


